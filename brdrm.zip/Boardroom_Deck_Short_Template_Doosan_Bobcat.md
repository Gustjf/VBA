# Boardroom Deck: Short Template (Doosan Bobcat)

A short prompt for a 4 to 6 sheet deck that presents a finished project to a manager. Paste it into an AI, attach the required files, and add your notes at the end.

---

## Required files (attach with this prompt)
- `doosan_logo.png`: Doosan wordmark in Doosan blue, transparent background.
- `bobcat_logo.png`: Bobcat head and wordmark in black, transparent background.

Use only these files for logos. Do not redraw, recolor, stretch or re-type either logo. If a file is missing, stop and ask for it.

---

Make a short landscape slide deck (11 x 17 or widescreen) that presents a finished project to a manager. Keep it minimal, professional and easy to talk to.

## Branding
- Accent color: Doosan blue, `#005EB8`. Use it for titles' accent rule, highlights, table headers and figures.
- Light tint for boxes and alternate table rows: `#EAF2FB`.
- Second color, only for anything still in progress: amber, `#C98A1B`.
- Text: near-black `#1E2329`; secondary text gray `#6B7280`; rules `#D6DAE0`; white background.
- Font: Helvetica (or Arial), bold for titles and labels.
- Every sheet:
  - a thin Doosan blue band across the top edge
  - logo lockup in the top-right corner, level with the title: `doosan_logo.png`, then `bobcat_logo.png`, side by side and centered on the same line, Bobcat slightly taller than Doosan so the wordmarks read at a similar size
  - a thin gray rule at the bottom with a source note on the left and the page number ("1 / 5") on the right

## Rules
- Plain, concise words. No hype.
- Each sheet's subtitle is the first sentence the presenter says.
- Don't repeat a fact on two sheets.
- Use only facts from the notes. Mark anything you drafted yourself.
- One accent color (Doosan blue), plus amber for anything still in progress.

## Sheets
1. **Agenda** (only for a meeting): a timeline drawn to scale, split into parts. Highlight the main item. End with one line: "We leave with: ...".
2. **Design Process:** the steps in order, in the past tense, each starting with a verb. Add a short table of how the work was checked, with real results.
3. **Architecture:**
   - where the files live
   - the parts of the system and how data flows between them, in one direction where possible
   - what goes in and what comes out
4. **User Guide:** the steps a user follows, a table of the buttons for loading and saving, and what the tool handles for the user.
5. **Value:** three headline figures (for example cost, consistency, scale), each with a short caption, then the proposed next steps.

## Finish
- Line up boxes that sit side by side.
- Keep labels clear of lines, box edges and the logo lockup.
- Check every sheet before handing it over.
- Output one PDF.

Add your notes below: the project, the audience, the meeting length, the main item, and the facts.

---

## Notes
<!-- project, audience, meeting length, main item, facts -->
